package com.example.animtuner

object Config {
    const val PKG = "com.example.animtuner"
    const val PREFS = "config"
    const val K_ENABLED = "enabled"
    const val K_WINDOW = "window"
    const val K_TRANSITION = "transition"
    const val K_ANIMATOR = "animator"
}

/** Hooked by LSPosed to return true when the module is active. */
object ModuleState {
    @JvmStatic
    fun isActive(): Boolean = false
}
