package com.example.animtuner

import android.content.ContentResolver
import android.os.SystemClock
import android.provider.Settings
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class Hook : IXposedHookLoadPackage {

    private val prefs: XSharedPreferences by lazy {
        XSharedPreferences(Config.PKG, Config.PREFS)
    }
    @Volatile private var lastReload = 0L

    private fun p(): XSharedPreferences {
        val now = SystemClock.uptimeMillis()
        if (now - lastReload > 1500) {
            prefs.reload()
            lastReload = now
        }
        return prefs
    }

    /** Returns the configured scale for a Settings.Global key, or null to leave it alone. */
    private fun scaleFor(key: String): Float? {
        val s = p()
        if (!s.getBoolean(Config.K_ENABLED, false)) return null
        return when (key) {
            Settings.Global.WINDOW_ANIMATION_SCALE -> s.getFloat(Config.K_WINDOW, 1f)
            Settings.Global.TRANSITION_ANIMATION_SCALE -> s.getFloat(Config.K_TRANSITION, 1f)
            Settings.Global.ANIMATOR_DURATION_SCALE -> s.getFloat(Config.K_ANIMATOR, 1f)
            else -> null
        }
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName == Config.PKG) {
            try {
                XposedHelpers.findAndHookMethod(
                    "com.example.animtuner.ModuleState", lpparam.classLoader, "isActive",
                    XC_MethodReplacement.returnConstant(true)
                )
            } catch (t: Throwable) {
                XposedBridge.log(t)
            }
            return
        }
        hookSettings()
        hookValueAnimator(lpparam.classLoader)
    }

    private fun hookSettings() {
        val cb = object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                val key = param.args.getOrNull(1) as? String ?: return
                scaleFor(key)?.let { param.result = it }
            }
        }
        try {
            XposedHelpers.findAndHookMethod(
                Settings.Global::class.java, "getFloat",
                ContentResolver::class.java, String::class.java,
                Float::class.javaPrimitiveType, cb
            )
            XposedHelpers.findAndHookMethod(
                Settings.Global::class.java, "getFloat",
                ContentResolver::class.java, String::class.java, cb
            )
        } catch (t: Throwable) {
            XposedBridge.log(t)
        }
    }

    private fun hookValueAnimator(cl: ClassLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.animation.ValueAnimator", cl, "getDurationScale",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        scaleFor(Settings.Global.ANIMATOR_DURATION_SCALE)?.let { param.result = it }
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log(t)
        }
    }
}
