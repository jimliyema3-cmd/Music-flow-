package com.example.animtuner

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var worldReadable = true

    private lateinit var swEnabled: Switch
    private val bars = HashMap<String, SeekBar>()
    private val labels = HashMap<String, TextView>()
    private var loading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("WorldReadableFiles")
    private fun openPrefs(): SharedPreferences = try {
        @Suppress("DEPRECATION")
        getSharedPreferences(Config.PREFS, MODE_WORLD_READABLE)
    } catch (e: SecurityException) {
        worldReadable = false
        getSharedPreferences(Config.PREFS, MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = openPrefs()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Anim Tuner"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        })

        val active = ModuleState.isActive() && worldReadable
        root.addView(TextView(this).apply {
            text = if (active) "● Module active"
            else "● Module NOT active. Enable it in LSPosed, tick \"System Framework\" (and any apps you want), then reboot."
            setTextColor(if (active) 0xFF2E7D32.toInt() else 0xFFC62828.toInt())
            setPadding(0, dp(6), 0, dp(16))
        })

        swEnabled = Switch(this).apply {
            text = "Enable animation override"
            setOnCheckedChangeListener { _, c ->
                if (!loading) prefs.edit().putBoolean(Config.K_ENABLED, c).apply()
            }
        }
        root.addView(swEnabled)

        addSlider(root, Config.K_WINDOW, "Window animation scale")
        addSlider(root, Config.K_TRANSITION, "Transition animation scale")
        addSlider(root, Config.K_ANIMATOR, "Animator duration scale")

        root.addView(section("Presets"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Default" to 1.0f, "Smooth" to 0.5f, "Fast" to 0.3f, "Off" to 0f).forEach { (n, v) ->
            row.addView(Button(this).apply {
                text = n
                isAllCaps = false
                setOnClickListener { setAll(v) }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)

        root.addView(section("Apply now"))
        root.addView(TextView(this).apply {
            text = "Writes the values to system settings so Android re-reads them immediately " +
                "(needs WRITE_SECURE_SETTINGS; a dialog explains how if it fails). " +
                "Otherwise changes apply after a reboot."
        })
        root.addView(Button(this).apply {
            text = "Apply to system settings"
            isAllCaps = false
            setOnClickListener { applySystem() }
        })

        load()
    }

    private fun section(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(20), 0, dp(6))
    }

    private fun addSlider(root: LinearLayout, key: String, title: String) {
        val label = TextView(this).apply { setPadding(0, dp(18), 0, 0); gravity = Gravity.START }
        val bar = SeekBar(this).apply {
            max = 60 // 0.00 .. 3.00 in 0.05 steps
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    label.text = "$title: ${fmt(p * 0.05f)}x"
                    if (fromUser && !loading) prefs.edit().putFloat(key, p * 0.05f).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        bars[key] = bar
        labels[key] = label
        root.addView(label)
        root.addView(bar)
    }

    private fun fmt(v: Float) = String.format("%.2f", v)

    private fun load() {
        loading = true
        swEnabled.isChecked = prefs.getBoolean(Config.K_ENABLED, false)
        bars.forEach { (k, b) -> b.progress = Math.round(prefs.getFloat(k, 1f) / 0.05f) }
        loading = false
    }

    private fun setAll(v: Float) {
        val e = prefs.edit().putBoolean(Config.K_ENABLED, true)
        bars.keys.forEach { e.putFloat(it, v) }
        e.apply()
        load()
    }

    private fun applySystem() {
        val w = prefs.getFloat(Config.K_WINDOW, 1f)
        val t = prefs.getFloat(Config.K_TRANSITION, 1f)
        val a = prefs.getFloat(Config.K_ANIMATOR, 1f)
        try {
            Settings.Global.putFloat(contentResolver, Settings.Global.WINDOW_ANIMATION_SCALE, w)
            Settings.Global.putFloat(contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, t)
            Settings.Global.putFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, a)
            Toast.makeText(this, "Applied", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            val cmd = "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
            AlertDialog.Builder(this)
                .setTitle("Permission needed")
                .setMessage("Run this once as root (KernelSU terminal, prefix with su) or via adb shell:\n\n$cmd")
                .setPositiveButton("Copy command") { _, _ ->
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("cmd", cmd))
                }
                .setNegativeButton("Close", null)
                .show()
        }
    }
}
