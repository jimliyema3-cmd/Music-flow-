# Anim Tuner (LSPosed module)

Configure window / transition / animator speed from a UI.

## Build
- Android Studio: open this folder, sync, Build > Build APK(s).
- No PC: push to GitHub; .github/workflows/build.yml builds the APK as a downloadable artifact.
- The Xposed API comes from https://api.xposed.info/ (de.robv.android.xposed:api:82).

## Use
1. Install the APK, then LSPosed > Modules > Anim Tuner > Enable.
2. Scope: tick "System Framework" plus any apps you want. Reboot.
3. Open Anim Tuner, enable the override, pick values.
4. Optional: `su -c pm grant com.example.animtuner android.permission.WRITE_SECURE_SETTINGS`
   so "Apply to system settings" applies changes instantly.
